const { BootstrapStarter } = require('@midwayjs/bootstrap');
const { Framework } = require('@midwayjs/faas');
const { asyncWrapper, start } = require('@midwayjs/serverless-scf-starter');
const { match } = require('path-to-regexp');
const layers = [];


let starter;
let runtime;
let inited = false;

const initializeMethod = async (initializeContext = {}) => {
  layers.unshift(engine => {
    engine.addRuntimeExtension({
      async beforeFunctionStart(runtime) {
        starter = new Framework();
        starter.configure({
          initializeContext,
          preloadModules: [],
          applicationAdapter: runtime
        });
        const boot = new BootstrapStarter();
        boot.configure({
          appDir: __dirname,
          
        }).load(starter);

        await boot.init();
        await boot.run();
      }
    });
  })
  runtime = await start({
    layers: layers,
    initContext: initializeContext,
    runtimeConfig: {"service":{"name":"midway-test"},"provider":{"name":"tencent","stage":"test"},"functions":{"index":{"handler":"index.handler","events":[{"http":{"method":"get","path":"/http"}}]},"index2":{"handler":"index.handler2","events":[{"apigw":{"method":"get","path":"/apigw"}}]}},"package":{"artifact":"artifact.zip"},"globalDependencies":{"@midwayjs/serverless-scf-starter":"*"}},
  });

  inited = true;
};

const getHandler = (hanlderName, ...originArgs) => {
  
    if (hanlderName === 'handler') {
      return  starter.handleInvokeWrapper('index.handler'); 
    }
  
    if (hanlderName === 'handler2') {
      return  starter.handleInvokeWrapper('index.handler2'); 
    }
  
}


 
exports.initializer = asyncWrapper(async (...args) => {
  if (!inited) {
    await initializeMethod(...args);
  }
});


 


exports.handler = asyncWrapper(async (...args) => {
  if (!inited) {
    await initializeMethod();
  }

  const handler = getHandler('handler', ...args);
  return runtime.asyncEvent(handler)(...args);
});

exports.handler2 = asyncWrapper(async (...args) => {
  if (!inited) {
    await initializeMethod();
  }

  const handler = getHandler('handler2', ...args);
  return runtime.asyncEvent(handler)(...args);
});



